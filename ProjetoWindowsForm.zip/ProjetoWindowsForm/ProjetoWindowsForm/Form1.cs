﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoWindowsForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            btnLimpar.ForeColor = Color.Red;
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);

            MessageBox.Show("Bem-vindo!!");
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);            
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValor.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int valor;
            if(int.TryParse(txtValor.Text, out valor) == false)
            {
                MessageBox.Show("Precisa ser um inteiro!",
                                "Oops...",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
            else
            {
                valor = valor * valor;
                txtValor.Text = valor.ToString();
            }
        }

        private void txtValor_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
